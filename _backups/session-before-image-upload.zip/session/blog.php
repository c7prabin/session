<h1>My Blog</h1>
<p>This is my personal blog. :D</p>
<div class="items">
    <div class="item">-
        <h2>Title 1 goes here...</h2>
        <ul class="list-inline">
            <li><strong>Written By: </strong>Administrator</li>
            <li><strong>Posted At: </strong>24 Aug, 2016</li>
        </ul>
        <div class="item-short-desc">
            Random text goes over here. THis is just a small block of text for you guys blah blah blah...
        </div>
        <a href="blog-details.php">Read more...</a>
    </div>
</div>
<div class="items">
    <div class="item">-
        <h2>Title 2 goes here...</h2>
        <ul class="list-inline">
            <li><strong>Written By: </strong>User 1</li>
            <li><strong>Posted At: </strong>25 Aug, 2016</li>
        </ul>
        <div class="item-short-desc">
             Random text goes over here. THis is just a small block of text for you guys blah blah blah...
        </div>
        <a href="blog-details.php">Read more...</a>
    </div>
</div>
