<?php
require_once '../config/db.php';
require_once '../config/functions.php';

//debug($_POST);

$blog_id = $_GET['blog_id'];


$sql = "DELETE FROM tbl_blogs WHERE blog_id = $blog_id";

$result = mysql_query($sql);

if($result){
    $_SESSION['flash_msg'] = 'Data deleted.';
    header('Location: blog.php');
} else {
    die('SQL Error: '. mysql_error());
}


