<div class="item-single">
    <div class="item">
        <h2>Title 2 goes here...</h2>
        <ul class="list-inline">
            <li><strong>Written By: </strong>User 1</li>
            <li><strong>Posted At: </strong>25 Aug, 2016</li>
        </ul>
        <div class="item-short-desc">
             <p>Random text goes over here. THis is just a small block of text for you guys blah blah blah...</p>
             <p>Random text goes over here. THis is just a small block of text for you guys blah blah blah...</p>
             <p>Random text goes over here. THis is just a small block of text for you guys blah blah blah...</p>
             <p>Random text goes over here. THis is just a small block of text for you guys blah blah blah...</p>
             <p>Random text goes over here. THis is just a small block of text for you guys blah blah blah...</p>
        </div>
        <a href="#!">Read more...</a>
    </div>
</div>
 