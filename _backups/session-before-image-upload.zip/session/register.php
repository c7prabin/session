<h1>Register Form</h1>
<form action="act-register.php" method="post">
    <table>
        <tr>
            <th><label>First Name</label></th>
            <td><input type="text" name="first_name"></td>
        </tr>
        <tr>
            <th><label>Last Name</label></th>
            <td><input type="text" name="last_name"></td>
        </tr>
        <tr>
            <th><label>Email</label></th>
            <td><input type="text" name="email"></td>
        </tr>
        <tr>
            <th><label>Password</label></th>
            <td><input type="password" name="password"></td>
        </tr>
        <tr>
            <th><label>Cell No.</label></th>
            <td><input type="text" name="cell_no"></td>
        </tr>
        <tr>
            <th><label>Date of Birth</label></th>
            <td><input type="text" name="date_of_birth"></td>
        </tr>
    </table>
    <button type="submit">Register Now</button>
</form>